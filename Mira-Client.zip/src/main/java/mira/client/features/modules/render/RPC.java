package mira.client.features.modules.render;

import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.AddServerScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import mira.client.MiraClient;
import mira.client.core.Managers;
import mira.client.features.modules.Module;
import mira.client.setting.Setting;
import mira.client.utility.Timer;
import mira.client.utility.discord.DiscordEventHandlers;
import mira.client.utility.discord.DiscordRPC;
import mira.client.utility.discord.DiscordRichPresence;

import java.io.*;
import java.util.Objects;

import static mira.client.features.modules.render.ClientSettings.isRu;

public final class RPC extends Module {
    private static final DiscordRPC rpc = DiscordRPC.INSTANCE;
    public static Setting<Mode> mode = new Setting<>("Picture", Mode.Recode);
    public static Setting<Boolean> showIP = new Setting<>("ShowIP", true);
    public static Setting<sMode> smode = new Setting<>("StateMode", sMode.Stats);
    public static Setting<String> state = new Setting<>("State", "Beta? Recode? NextGen?");
    public static Setting<Boolean> nickname = new Setting<>("Nickname", true);
    public static DiscordRichPresence presence = new DiscordRichPresence();
    public static boolean started;
    static String String1 = "none";
    private final Timer timer_delay = new Timer();
    private static Thread thread;
    String slov;
    String[] rpc_perebor_en = {"Parkour", "Reporting cheaters", "Touching grass", "Asks how to bind", "Reporting bugs", "Watching Kilab"};
    String[] rpc_perebor_ru = {"Паркурит", "Репортит читеров", "Трогает траву", "Спрашивает как забиндить", "Репортит баги", "Смотрит Флюгера"};
    int randomInt;

    public RPC() {
        super("DiscordRPC", Category.RENDER);
    }

    public static void readFile() {
        try {
            File file = new File("MiraClient/misc/RPC.txt");
            if (file.exists()) {
                try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                    while (reader.ready()) {
                        String1 = reader.readLine();
                    }
                }
            }
        } catch (Exception ignored) {
        }
    }

    public static void WriteFile(String url1, String url2) {
        File file = new File("MiraClient/misc/RPC.txt");
        try {
            file.createNewFile();
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                writer.write(url1 + "SEPARATOR" + url2 + '\n');
            } catch (Exception ignored) {
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onDisable() {
        started = false;
        if (thread != null && !thread.isInterrupted()) {
            thread.interrupt();
        }
        if (rpc != null) {
            try {
                rpc.Discord_Shutdown();
            } catch (Throwable ignored) {}
        }
    }

    @Override
    public void onUpdate() {
        startRpc();
    }

    public void startRpc() {
        if (isDisabled()) return;
        if (rpc == null) return;
        if (!started) {
            started = true;
            try {
                DiscordEventHandlers handlers = new DiscordEventHandlers();
                rpc.Discord_Initialize("1093053626198523935", handlers, true, "");
                presence.startTimestamp = (System.currentTimeMillis() / 1000L);
                presence.largeImageText = "v" + MiraClient.VERSION + " [" + MiraClient.GITHUB_HASH + "]";
                rpc.Discord_UpdatePresence(presence);
            } catch (Throwable ignored) {
                return;
            }

            thread = new Thread(() -> {
                while (!Thread.currentThread().isInterrupted()) {
                    try {
                        if (rpc != null) {
                            rpc.Discord_RunCallbacks();
                            presence.details = getDetails();

                            switch (smode.getValue()) {
                                case Stats ->
                                        presence.state = "Hacks: " + Managers.MODULE.getEnabledModules().size() + " / " + Managers.MODULE.modules.size();
                                case Custom -> presence.state = state.getValue();
                                case Version -> presence.state = "v" + MiraClient.VERSION +" for mc 1.21";
                            }

                            if (nickname.getValue()) {
                                presence.smallImageText = "logged as - " + mc.getSession().getUsername();
                                presence.smallImageKey = "https://minotar.net/helm/" + mc.getSession().getUsername() + "/100.png";
                            } else {
                                presence.smallImageText = "";
                                presence.smallImageKey = "";
                            }

                            presence.button_label_1 = "Download";
                            presence.button_url_1 = "https://github.com/Pan4ur/MiraClient-Recode/";

                            switch (mode.getValue()) {
                                case Recode -> presence.largeImageKey = "https://i.imgur.com/yY0z2Uq.gif";
                                case MegaCute ->
                                        presence.largeImageKey = "https://media1.tenor.com/images/6bcbfcc0be97d029613b54f97845bc59/tenor.gif?itemid=26823781";
                                case Custom -> {
                                    readFile();
                                    presence.largeImageKey = String1.split("SEPARATOR")[0];
                                    if (!Objects.equals(String1.split("SEPARATOR")[1], "none")) {
                                        presence.smallImageKey = String1.split("SEPARATOR")[1];
                                    }
                                }
                            }
                            rpc.Discord_UpdatePresence(presence);
                        }
                        Thread.sleep(2000L);
                    } catch (InterruptedException ignored) {
                        break;
                    } catch (Throwable ignored) {
                    }
                }
            }, "TH-RPC-Handler");
            thread.start();
        }
    }

    private String getDetails() {
        String result = "";

        if (mc.currentScreen instanceof MultiplayerScreen || mc.currentScreen instanceof AddServerScreen || mc.currentScreen instanceof TitleScreen) {
            if(timer_delay.passedMs(60 * 1000)){
                randomInt = (int)(Math.random() * (5 - 0 + 1) + 0);
                slov = isRu() ? rpc_perebor_ru[randomInt] : rpc_perebor_en[randomInt];
                timer_delay.reset();
            }
            result = slov;
        } else if (mc.getCurrentServerEntry() != null) {
            result = isRu() ? (showIP.getValue() ? "Играет на " + mc.getCurrentServerEntry().address : "Играет на сервере") : (showIP.getValue() ? "Playing on " + mc.getCurrentServerEntry().address : "Playing on server");
        } else if (mc.isInSingleplayer()) {
            result = isRu() ? "Читерит в одиночке" : "SinglePlayer hacker";
        }
        return result;
    }

    public enum Mode {Custom, MegaCute, Recode}

    public enum sMode {Custom, Stats, Version}
                }
